const textdif = (prefix) => {
	return `

╭──────────────╮
 *𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎 𝘿𝙊 𝙉𝙄𝘾𝙆 💠*
╰──────────────╯
 
➸ *${prefix}party*
➸ *${prefix}galaxtext*
➸ *${prefix}rtext*
➸ *${prefix}water*
➸ *${prefix}firetext*
➸ *${prefix}textdark*
➸ *${prefix}textblue*
➸ *${prefix}textsky*
➸ *${prefix}texteng*

╭───────────────╮
       𝙈𝙀𝙉𝙐 𝘿𝙊 𝙉𝙄𝘾𝙆 💠
╰───────────────╯

➸ *${prefix}help1* 


╭───────────────╮
  FEITO POR *NICKZZIN*
  Wa.me/5512997277680
╰───────────────╯`
}

exports.textdif = textdif