const animesd = (prefix) => {

    return `
╭───────────────╮
➼✰        💠𝘽𝙊𝙏𝙕𝙕𝙄𝙉💠
      𝘾𝙊𝙈𝘼𝙉𝘿𝙊𝙎 𝘿𝙊 𝙉𝙄𝘾𝙆 💠
╰───────────────╯

➸ *${prefix}naruto*
➸ *${prefix}minato*
➸ *${prefix}boruto*
➸ *${prefix}hinata*
➸ *${prefix}sasuke*
➸ *${prefix}sakura*
➸ *${prefix}unta*
➸ *${prefix}kaneki*
➸ *${prefix}toukachan*
➸ *${prefix}rize*
➸ *${prefix}akira*
➸ *${prefix}itori*
➸ *${prefix}kurumi*
➸ *${prefix}miku*
➸ *${prefix}  *
➸ *${prefix}  *
➸ *${prefix}  *
➸ *${prefix}  *
➸ *${prefix}  *
➸ *${prefix}  *


╭──────────────────────────╮
*𝙉𝙄𝘾𝙆𝙕𝙕𝙄𝙉 𝙔𝙏 𝙊 𝙈𝘼𝙄𝙎 𝘽𝙍𝘼𝘽𝙊 𝘿𝙊𝙎 𝘽𝙍𝘼𝘽𝙊* 🤗
*Digite ${prefix}dono para mais info*
╰──────────────────────────╯`

}
exports.animesd = animesd